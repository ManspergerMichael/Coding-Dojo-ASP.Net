﻿using System;

namespace Human
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Human TazerFace = new Human("TazerFace!");
            System.Console.WriteLine(TazerFace.name);
            TazerFace.attack(TazerFace);
            System.Console.WriteLine(TazerFace.health);
        }
    }
}
