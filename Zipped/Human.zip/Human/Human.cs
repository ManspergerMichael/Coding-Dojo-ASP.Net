namespace Human{
   class Human{
       public string name;
       public int strength = 3;
       public int intelligence = 3;
       public int dexterity = 3;
       public int health = 100;

       public Human(string name){
           this.name = name;
       }
       public Human(string name, int strength, int intelligence, int dexterity, int health){
           this.name = name;
           this.strength = strength;
           this.intelligence = intelligence;
           this.dexterity = dexterity;
           this.health = health;
       }

       public object attack(object guy){
            int damage = this.strength * 5;
            if(guy is Human){
            Human temp = guy as Human;
            temp.health = temp.health - damage;
            guy = temp as object;
            return guy;
            }
            else{
                return "you suck!";
            }
            
           
       }
   }
}